document.addEventListener('DOMContentLoaded', () => {
    console.log('main.js loaded');

    // Initialize Bootstrap modals
    const modals = document.querySelectorAll('.modal');
    modals.forEach(modal => {
        console.log('Initializing modal:', modal.id);
        try {
            const bsModal = new bootstrap.Modal(modal);
            modal.addEventListener('shown.bs.modal', () => {
                console.log('Modal shown:', modal.id);
            });
            modal.addEventListener('hidden.bs.modal', () => {
                console.log('Modal hidden:', modal.id);
            });
        } catch (error) {
            console.error('Error initializing modal:', modal.id, error);
        }
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });

    // Form validation for all forms with needs-validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            console.log('Form submitted:', form.action, form.querySelector('input[name="action"]')?.value);
            // Check for at least one checkbox selected (for add schedule form)
            const checkboxes = form.querySelectorAll('input[type="checkbox"][name="day_of_week[]"]');
            let isCheckboxSelected = true;
            if (checkboxes.length > 0) {
                isCheckboxSelected = false;
                checkboxes.forEach(checkbox => {
                    if (checkbox.checked) {
                        isCheckboxSelected = true;
                    }
                });
            }

            if (!form.checkValidity() || !isCheckboxSelected) {
                event.preventDefault();
                event.stopPropagation();
                console.log('Form validation failed. Checkboxes selected:', isCheckboxSelected);
                if (!isCheckboxSelected && checkboxes.length > 0) {
                    const checkboxContainer = form.querySelector('.d-flex.flex-wrap');
                    if (checkboxContainer) {
                        checkboxContainer.classList.add('is-invalid');
                        const feedback = checkboxContainer.querySelector('.invalid-feedback') || document.createElement('div');
                        feedback.className = 'invalid-feedback';
                        feedback.textContent = 'Please select at least one day.';
                        checkboxContainer.appendChild(feedback);
                    }
                }
            } else {
                console.log('Form validation passed');
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Fade-in animation trigger
    const fadeElements = document.querySelectorAll('.fade-in');
    fadeElements.forEach(el => {
        el.style.opacity = '0';
        setTimeout(() => {
            el.style.opacity = '1';
        }, 100);
    });
});
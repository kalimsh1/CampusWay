<?php
require_once 'db.php';

if (isset($_POST['teacher_id'])) {
    $teacher_id = filter_var($_POST['teacher_id'], FILTER_SANITIZE_NUMBER_INT);
    $stmt = $conn->prepare("SELECT day_of_week, start_time, end_time, office_location FROM teacher_schedules WHERE teacher_id = ? ORDER BY FIELD(day_of_week, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday')");
    $stmt->bind_param("i", $teacher_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo '<p>No schedule available for this teacher.</p>';
    } else {
        echo '<h4>Weekly Schedule</h4>';
        echo '<table class="table table-bordered">';
        echo '<thead><tr><th>Day</th><th>Start Time</th><th>End Time</th><th>Office</th></tr></thead>';
        echo '<tbody>';
        while ($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>' . htmlspecialchars($row['day_of_week']) . '</td>';
            echo '<td>' . htmlspecialchars($row['start_time']) . '</td>';
            echo '<td>' . htmlspecialchars($row['end_time']) . '</td>';
            echo '<td>' . htmlspecialchars($row['office_location']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    }
}
?>
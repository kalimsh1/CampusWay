<style>
    .custom-footer {
        background-color: #f2edfc;
        padding: 40px 20px;
        text-align: center;
        border-top-right-radius: 40px;
        border-top-left-radius: 40px;
        font-family: 'Poppins', sans-serif;
        color: #5b2bd1;
        margin-top: 80px;
    }

    .footer-icons {
        margin: 20px 0;
    }

    .footer-icons a {
        display: inline-block;
        margin: 0 10px;
        background-color: #5b2bd1;
        color: white;
        font-size: 18px;
        padding: 10px;
        border-radius: 50%;
        transition: transform 0.3s ease;
    }

    .footer-icons a:hover {
        transform: scale(1.2);
    }

    .footer-logo {
        font-weight: bold;
        font-size: 20px;
        margin-bottom: 10px;
    }

    .footer-copy {
        font-size: 14px;
        color: #5b2bd1;
    }
</style>

<div class="custom-footer">
    <div class="footer-logo">CampusWay</div>

   

    <div class="footer-copy">
        &copy; 2025 CampusWay. All rights reserved.
    </div>
</div>

<!-- Bootstrap Icons -->
<lin


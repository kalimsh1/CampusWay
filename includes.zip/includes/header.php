<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (isset($_GET['lang'])) {
    $_SESSION['lang'] = $_GET['lang'];
}
$lang = $_SESSION['lang'] ?? 'ar';

$labels = [
    'ar' => [
        'home' => 'الرئيسية',
        'map' => 'الخريطة',
        'find_teacher' => 'جدول المحاضر',
        'facilities' => 'المرافق',
        'help' => 'المساعدة',
        'lang_btn' => 'En'
    ],
    'en' => [
        'home' => 'Home',
        'map' => 'Map',
        'find_teacher' => 'Find Lecturer Schedule',
        'facilities' => 'Facilities',
        'help' => 'Help',
        'lang_btn' => 'عربي'
    ]
];

// Preserve existing query parameters for language toggle
$query_params = $_GET;
?>
<style>
    body {
        direction: <?= $lang === 'ar' ? 'rtl' : 'ltr' ?>;
        background-color: #ffffff !important;
        margin: 0;
    }

    .navbar-container {
        background-color: #ffffff !important;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
        padding: 12px 20px;
        font-family: 'Poppins', sans-serif;
    }

    .navbar {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        background-color: #ffffff !important;
    }

    .navbar .logo img {
        height: 70px;
    }

    .menu-btn {
        font-size: 26px;
        background: none;
        border: none;
        color: #5b2bd1;
        cursor: pointer;
        display: none;
    }

    .nav-links {
        display: flex;
        gap: 16px;
        align-items: center;
    }

    .nav-links a {
        text-decoration: none;
        color: #333;
        font-weight: 500;
        padding: 6px 14px;
        border-radius: 10px;
        transition: 0.3s ease;
    }

    .nav-links a:hover,
    .nav-links a.active {
        background-color: #5b2bd1;
        color: white;
    }

    .nav-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-top: 10px;
    }

    .login-btn {
        background-color: #5b2bd1;
        color: white;
        padding: 7px 16px;
        border-radius: 10px;
        text-decoration: none;
        font-weight: 500;
    }

    .lang-btn {
        background-color: #f2edfc;
        color: #5b2bd1;
        padding: 6px 12px;
        border-radius: 10px;
        text-decoration: none;
        font-weight: 500;
    }
    
    @media (max-width: 768px) {
        .menu-btn {
            display: block;
        }

        .nav-links {
            display: none;
            flex-direction: column;
            width: 100%;
            margin-top: 10px;
        }

        .nav-links.show {
            display: flex;
        }

        .nav-actions {
            flex-direction: column;
            align-items: flex-start;
            width: 100%;
        }
    }
</style>

<div class="navbar-container">
    <div class="navbar">
        <?php if ($lang === 'ar'): ?>
            <!-- عربي: الشعار يسار والقائمة يمين -->
            <div class="logo">
                <a href="index.php">
                    <img src="images/logo.png" alt="CampusWay" />
                </a>
            </div>

            <button class="menu-btn" onclick="toggleMenu()">☰</button>

            <div class="nav-links" id="menu">
                <a href="index.php" class="active"><?= $labels[$lang]['home'] ?></a>
                <a href="map.php"><?= $labels[$lang]['map'] ?></a>
                <a href="search-teacher-office.php"><?= $labels[$lang]['find_teacher'] ?></a>
                <a href="facilities.php"><?= $labels[$lang]['facilities'] ?></a>
                <a href="help.php"><?= $labels[$lang]['help'] ?></a>
                <div class="nav-actions">
                    <?php
                    $query_params['lang'] = 'en';
                    $query_string = http_build_query($query_params);
                    ?>
                    <a href="?<?= $query_string ?>" class="lang-btn"><?= $labels[$lang]['lang_btn'] ?></a>
                </div>
            </div>
        <?php else: ?>
            <!-- إنجليزي: الشعار يمين والقائمة يسار -->
            <div class="logo">
                <a href="index.php">
                    <img src="images/logo.png" alt="CampusWay" />
                </a>
            </div>

            <button class="menu-btn" onclick="toggleMenu()">☰</button>

            <div class="nav-links" id="menu">
                <a href="index.php" class="active"><?= $labels[$lang]['home'] ?></a>
                <a href="map.php"><?= $labels[$lang]['map'] ?></a>
                <a href="search-teacher-office.php"><?= $labels[$lang]['find_teacher'] ?></a>
                <a href="facilities.php"><?= $labels[$lang]['facilities'] ?></a>
                <a href="help.php"><?= $labels[$lang]['help'] ?></a>
                <div class="nav-actions">
                    <?php
                    $query_params['lang'] = 'ar';
                    $query_string = http_build_query($query_params);
                    ?>
                    <a href="?<?= $query_string ?>" class="lang-btn"><?= $labels[$lang]['lang_btn'] ?></a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    function toggleMenu() {
        document.getElementById("menu").classList.toggle("show");
    }
</script>
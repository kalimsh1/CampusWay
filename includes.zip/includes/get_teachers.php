<?php
require_once 'db.php';

if (isset($_POST['query'])) {
    $query = "%" . filter_var($_POST['query'], FILTER_SANITIZE_STRING) . "%";
    $stmt = $conn->prepare("SELECT teacher_id, name, department, office_number FROM teachers WHERE name LIKE ?");
    $stmt->bind_param("s", $query);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo '<p>No lecturers found.</p>';
    } else {
        while ($row = $result->fetch_assoc()) {
            echo '<div class="col-md-4 mb-3">';
            echo '<div class="card">';
            echo '<div class="card-body">';
            echo '<h5 class="card-title">' . htmlspecialchars($row['name']) . '</h5>';
            echo '<p class="card-text">Department: ' . htmlspecialchars($row['department']) . '<br>';
            echo 'Office: ' . htmlspecialchars($row['office_number']) . '</p>';
            echo '<button class="btn btn-primary" onclick="showSchedule(' . $row['teacher_id'] . ')">View Schedule</button>';
            echo '</div></div></div>';
        }
    }
}
?>